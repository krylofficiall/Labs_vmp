﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace lab5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Добро пожаловать в систему учета персонала");
            Console.Write("Укажите количество всех людей: ");
            int person_count = Int32.Parse(Console.ReadLine());
            Person[] persons = new Person[person_count];

            Console.WriteLine("Теперь введите имя и возраст всех людей: ");
            for (int i = 0; i < person_count; i++)
            {
                string[] answer = Console.ReadLine().Split();
                Person person_current = new Person(answer[0], Int32.Parse(answer[1]));
                persons[i] = person_current;
            }

            Console.Write("Студенты добавлены, теперь укажите количество учителей: ");
            int teachers_count = Int32.Parse(Console.ReadLine());
            Teacher[] teachers = new Teacher[teachers_count];
            Console.WriteLine("Теперь введите имя и возраст всех учителей: ");
            for (int i = 0; i < teachers_count; i++)
            {
                string[] answer = Console.ReadLine().Split();
                Teacher teacher_current = new Teacher(answer[0], Int32.Parse(answer[1]));
                teachers[i] = teacher_current;
            }

            Console.WriteLine("Введите количество студентов ");
            int students_current = Int32.Parse(Console.ReadLine());
            StudentWithAdvisor[] students = new StudentWithAdvisor[students_current];
            Console.WriteLine("Теперь введите имя, возраст, курс и преподавателя для каждого студента");
            for (int i = 0; i < students_current; i++)
            {
                Teacher teacher = new Teacher("ERROR", 0);
                string[] answer = Console.ReadLine().Split();
                for (int j = 0; j < teachers_count; j++)
                {
                    if (answer[3] == teachers[j].Name)
                        teacher = teachers[j];
                }
                if (teacher.Name == "ERROR")
                    Console.WriteLine("Данного учителя не существует");
                else
                {
                    StudentWithAdvisor swa_current = new StudentWithAdvisor(answer[0], Int32.Parse(answer[1]), Int32.Parse(answer[2]), teacher);
                    students[i] = swa_current;
                    teacher.PlusStudent(swa_current);
                }
            }

            string answer_menu = "";
            Console.WriteLine("Введите help, чтобы вызывать список команд");

            while (answer_menu != "exit")
            {
                Console.Write(">> ");
                answer_menu = Console.ReadLine();

                if (answer_menu == "help")
                {
                    Console.WriteLine("people - показать список людей");
                    Console.WriteLine("teachers - показать список учителей");
                    Console.WriteLine("students - показать список студентов");
                    Console.WriteLine("randp - показать случайного пользователя");
                    Console.WriteLine("randt - показать случайного учителя");
                    Console.WriteLine("rands - показать случайного студента");
                    Console.WriteLine("exit - выход");
                }
                else if (answer_menu == "people")
                {
                    foreach (var person in persons)
                    {
                        person.Print();
                    }
                }
                else if (answer_menu == "teachers")
                {
                    foreach (var person in teachers)
                    {
                        person.Print();
                    }
                }
                else if (answer_menu == "students")
                {
                    foreach (var person in students)
                    {
                        person.Print();
                    }
                }
                else if (answer_menu == "randp")
                {
                    int count = persons[0].RandomPerson(person_count);
                    Console.WriteLine(persons[count]);
                }
                else if (answer_menu == "randt")
                {
                    int count = teachers[0].RandomPerson(teachers_count);
                    Console.WriteLine(teachers[count]);
                }
                else if (answer_menu == "rands")
                {
                    int count = students[0].RandomPerson(students_current);
                    Console.WriteLine(students[count]);
                }
                else if (answer_menu == "exit")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Введена неверная команд. Введите help, чтобы вызывать список команд.");
                }
            }
        }
    }
}
