﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_1
{
    class Student : Person
    {
        private int course;
        private Student student;

        public Student(string Name, int Age, int Course) : base(Name, Age)
        {
            course = Course;
        }
        public Student(Student standart)
            : base(standart)
        {
            Course = standart.Course;
        }

        public int Course
        {
            get { return course; }
            set
            {
                if (course < 0) value = 0;
                else if (course > 4) value = 4;
                course = value;
            }
        }
        public override string ToString()
        {
            return "Name: " + Name.ToString() + "; Age: " + Age.ToString() + " Course: " + Course.ToString();
        }

        public override bool Equals(object item)
        {
            return item != null && item.GetType() == GetType() && item.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ Age.GetHashCode() ^ Course.GetHashCode();
        }

        public override Person Clone()
        {
            return new Student(this);
        }

        public override void Print()
        {
            Console.WriteLine(ToString());
        }

        public int RandomStudent(int n)
        {
            Random random = new Random();
            int count = random.Next(0, n);
            return count;
        }
    }
}
