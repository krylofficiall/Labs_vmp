﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_1
{
    class Person : Object
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private int age;
        public int Age
        {
            get { return age; }
            set
            {
                if (value < 0)
                    value = 0;
                age = value;
            }
        }
        public override string ToString()
        {
            return "Имя человека: " + name.ToString() + ", Возраст: " + age.ToString();
        }

        public override bool Equals(object item)
        {
            return item != null && item.GetType() == GetType() && item.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ Age.GetHashCode();
        }

        public int RandomPerson(int n)
        {
            Random random = new Random();
            int count = random.Next(0, n);
            return count;
        }

        public virtual Person Clone()
        {
            return new Person(this);
        }

        public virtual void Print()
        {
            Console.WriteLine(ToString());
        }
        public Person(string Name, int Age)
        {
            name = Name;
            age = Age;
        }

        public Person(Person standart)
        {
            Name = standart.Name;
            Age = standart.Age;
        }

       
    }
}
