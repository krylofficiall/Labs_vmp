﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_1
{
    class StudentWithAdvisor : Student
    {
        private Teacher teacher;
        public Teacher Teacher
        {
            get { return teacher; }
            set { teacher = value; }
        }

        public StudentWithAdvisor(string Name, int Age, int Course, Teacher Teacher)
            : base(Name, Age, Course)
        {
            teacher = Teacher;
        }

        public StudentWithAdvisor(StudentWithAdvisor standart)
            : base(standart)
        {
            Teacher = standart.Teacher;
        }

        public override string ToString()
        {
            return "Name: " + Name.ToString() + "; Age:  " + Age.ToString() + "; Course: " + Course.ToString() + "; Teacher: " + teacher.Name.ToString();
        }

        public override bool Equals(object item)
        {
            return item != null && item.GetType() == GetType() && item.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ Age.GetHashCode() ^ Course.GetHashCode();
        }

        public override Person Clone()
        {
            return new StudentWithAdvisor(this);
        }
        public override void Print()
        {
            Console.WriteLine(ToString());
        }
    }
}
