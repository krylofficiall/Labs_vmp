﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_1
{
    class Teacher : Person
    {
        private List<StudentWithAdvisor> students;
        public Teacher(string Name, int Age)
            : base(Name, Age)
        {
            students = new List<StudentWithAdvisor>();
        }
        public Teacher(Teacher standart)
            : base(standart)
        {
            Students = standart.Students;
        }

        public void PlusStudent(StudentWithAdvisor Student)
        {
            students.Add(Student);
        }

        public List<StudentWithAdvisor> Students
        {
            get { return students; }
            set { students = value; }
        }

        public override string ToString()
        {
            return "\nИмя учителя: " + Name.ToString() + ", возраст учителя: " + Age.ToString() + ", обучаемые студенты: " + string.Join(", ", Students.Select(students_current => students_current.Name));
        }

        public override bool Equals(object item)
        {
            return item != null && item.GetType() == GetType() && item.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ Age.GetHashCode();
        }

        public override Person Clone()
        {
            return new Teacher(this);
        }

        public override void Print()
        {
            Console.WriteLine(ToString());
        }

        public int RandomTeacher(int n)
        {
            Random random = new Random();
            return random.Next(0, n);
        }
    }
}
